# Pokemon-Database
Mysql Relational Database.
MySQL Workbench: Full database can be viewed by importing the dump20160519-1.sql into workbench.
Database of 722 pokemon.
14 Tables
5 views
12 stored procedures
