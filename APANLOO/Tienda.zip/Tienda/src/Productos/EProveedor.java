package Productos;

/**
 * EProveedor
 *
 */
public enum EProveedor {
    GAMESA, FEMSA, PEPSICO
}
