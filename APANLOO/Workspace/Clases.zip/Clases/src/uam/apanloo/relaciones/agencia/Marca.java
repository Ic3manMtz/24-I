package uam.apanloo.relaciones.agencia;

public enum Marca {
  KIA, NISSAN, VW, FORD, GM
}
