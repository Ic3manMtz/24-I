package uam.apanloo.relaciones.agencia;

public enum Color {
  ROJO, BLANCO, AZUL, VERDE
}
