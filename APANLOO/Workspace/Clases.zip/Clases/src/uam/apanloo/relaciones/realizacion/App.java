package uam.apanloo.relaciones.realizacion;

public class App {
  public static void main(String[] args) {
    Automovil automovil = new Automovil();

    automovil.arrancar();
    automovil.acelerar();
    automovil.detener();
  }
}
