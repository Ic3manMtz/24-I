package uam.apanloo.relaciones.biblioteca;

public enum Pais {
  MEXICO, ESTADOS_UNIDOS, CANADA, HONDURAS, GUATEMALA
}
