package uam.apanloo.relaciones.agregacion;

public enum Marca {
  KIA, NISSAN, BMW, AUDI;
}
