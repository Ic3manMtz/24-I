package uam.apanloo.relaciones.realizacion;

public class Automovil implements  Vehiculo {

  @Override
  public void acelerar() {
    // TODO Auto-generated method stub
    System.out.println("El automovil está acelerando");
  }

  @Override
  public void arrancar() {
    // TODO Auto-generated method stub
    System.out.println("El automóvil está arrancando");
  }

  @Override
  public void detener() {
    // TODO Auto-generated method stub
    System.out.println("El automóvil se ha detenido");
  }

}
