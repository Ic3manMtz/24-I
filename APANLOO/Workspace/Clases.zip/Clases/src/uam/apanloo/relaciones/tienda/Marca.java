package uam.apanloo.relaciones.tienda;

public enum Marca {
  ALPURA, LALA, GAMESA, TIA_ROSA
}
