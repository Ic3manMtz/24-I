package uam.apanloo.relaciones.agencia;

public enum Modelo {
  VERSA, SENTRA, NP400, ALTIMA, MAXIMA
}
